<?php $__env->startSection('content'); ?>
<!--breadcrumb-->
<?php $__env->startSection('css'); ?>
<style type="text/css" media="screen">
    .header-breadcrumb {
        background: url(<?php echo e(img_header($header->profil)); ?>) no-repeat scroll center 0 transparent;
        -webkit-background-size: cover;
        background-size: cover;
    }
    .who-area {
        background: url('') no-repeat scroll center 0 transparent;
        position: relative!important;
    }
    .who-area .who-are-image:after{
             border: 0px solid #fff; 
    }
</style>
<?php $__env->stopSection(); ?>
<section class="row header-breadcrumb">
    <div class="container">
            <div class="row m0 page-cover">
                <h2 class="page-cover-tittle">Profil Desa</h2>
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Profil</li>
            </ol>
            </div>
        </div>
</section>

<!--who-are-->
<section class=" row who-area sectpad">
    <div class="container">
        <div class="row m0 section_header color">
            <h2>Sejarah Desa</h2> 
        </div>
        <div class="row">
            <div class="col-sm-4 col-lg-3 who-are">
                <div class="who-are-image row m0">
                    <img src="<?php echo e(img_profil($profil->gambar)); ?>" alt="<?php echo e($profil->nama_desa); ?>">
                </div>
            </div>
            <div class="col-sm-8 col-lg-9 who-are-texts">
                <div class="who-text">
                    <h3><?php echo e($profil->nama_desa); ?></h3>
                    <p><?php echo $profil->deskripsi; ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--features-->

<!--team-->
 <section class="row sectpad team-area">
    <div class="container">
        <div class="row m0 section_header color">
            <h2>Aparatur Desa</h2> 
        </div>
        <div class="row our-team">
            <?php $__currentLoopData = $pejabat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-3 team">
                <div class="team-images row m0">
                    <img style="max-width: 209px;max-height: 282px;min-height: 282px" src="<?php echo e(img_pejabat($result->foto)); ?>" alt="">
                </div>
                <div class="team-content">
                    <a href="#"><h4><?php echo e($result->nama); ?></h4></a>
                    <p><?php echo e($result->jabatan); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<!--testimonial-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>