<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e($config->name); ?></title>

	<!-- Global stylesheets -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/main/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(base_url('')); ?>assets/css/common.css">
	<link href="<?php echo e(base_url()); ?>assets/main/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/main/css/core.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/main/css/components.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/main/css/colors.css" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->
	<?php echo $__env->yieldContent('style'); ?>
	<!-- Core JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/loaders/blockui.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/ui/nicescroll.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/ui/drilldown.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/media/fancybox.min.js"></script>

	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/core/app.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/pages/gallery.js"></script>

	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/plugins/ui/ripple.min.js"></script>
	<!-- /theme JS files -->
	<?php echo $__env->yieldContent('js'); ?>
	<style type="text/css">
		.navbar-brand > img {
		    margin-top: -5px;
		    height: 30px;
		}
		fieldset {
			border: 3px groove;
			display: block;
			text-align: justify
		}
		body {
			background: url("<?php echo e(base_url()); ?>assets/images/bagroundnexapp-01.jpg") no-repeat center center fixed;
			-webkit-background-size: 100% 100%;
			-moz-background-size: 100% 100%;
			-o-background-size: 100% 100%;
			background-size: 100% 100%;
			opacity: 0.9;
    		/* filter: alpha(opacity=50); */
			/* width: 100%;
			height: 100%; */
		}
		p, h4 {
			text-align: justify;
		}
	</style>
</head>

<body>
	
	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?php echo e(base_url()); ?>"><img src="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>" alt=""></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-users"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">

			<!-- <p class="navbar-text"><span class="label bg-success-400">Online</span></p> -->
			<ul class="nav navbar-nav navbar-right">
				<p class="navbar-text"><span class="label bg-warning-400"><?php echo e(ucwords($ctrl->session->userdata('authmember_status'))); ?></span></p>
				<li class="dropdown dropdown-user">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<img src="<?php echo e(base_url()); ?>assets/main/images/placeholder.jpg" alt="">
						<span><?php echo e(ucwords($ctrl->session->userdata('authmember_name'))); ?></span>
						<i class="caret"></i>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						<li class="divider"></li>
						<li><a href="<?php echo e(base_url('main/riwayat')); ?>"><i class="icon-cog5"></i> Riwayat</a></li>
						<li><a href="<?php echo e(base_url('authentication/logout')); ?>"><i class="icon-switch2"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->


	<!-- Second navbar -->
	<div class="navbar navbar-default" id="navbar-second">
		<ul class="nav navbar-nav no-border visible-xs-block">
			<li><a class="text-center collapsed" data-toggle="collapse" data-target="#navbar-second-toggle"><i class="icon-menu7"></i></a></li>
		</ul>

		<div class="navbar-collapse collapse" id="navbar-second-toggle">
			<ul class="nav navbar-nav navbar-nav-material">
				<li><a href="<?php echo e(base_url('main')); ?>"><i class="icon-home position-left"></i> Home</a></li>
				

				
			</ul>
		</div>
	</div>
	<!-- /second navbar -->


	<!-- Page header -->
	

			<?php echo $__env->yieldContent('content'); ?>

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
	<div id="modal_simulasi" class="modal fade" data-keyboard="false">
					<div class="modal-dialog">
						<div class="modal-content">
							<!-- <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h5 class="modal-title">Disable keyboard interaction</h5>
							</div> -->

							<div class="modal-body">
								<h6 class="text-semibold">Simulasi</h6>
								<div class="row">
									<div class="col-md-12">
										<div class="panel panel-flat">
											<div class="panel-heading">
												<h6 class="panel-title">Tryout<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
											</div>

											<div class="panel-body">
												<div class="tabbable">
													<ul class="nav nav-tabs nav-tabs-highlight">
													<?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><a href="#highlighted-tab<?php echo e($result->id_jenjang); ?>" data-toggle="tab" class="legitRipple"><?php echo e($result->nm_jenjang); ?></a></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>

													<div class="tab-content">
														<?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<div class="tab-pane" id="highlighted-tab<?php echo e($result->id_jenjang); ?>">
															<?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($result->id_jenjang==$resultM->id_jenjang): ?>
																<a href="<?php echo e(base_url('main/tryout/'.$resultM->id_mapel)); ?>"><button type="submit" style="margin-top: 15px" class="btn btn-primary legitRipple"><?php echo e($resultM->nm_mapel); ?> <i class="icon-arrow-right14 position-right"></i></button></a>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="panel panel-flat">
											<div class="panel-heading">
												<h6 class="panel-title">Prediksi<a class="heading-elements-toggle"><i class="icon-more"></i></a></h6>
											</div>

											<div class="panel-body">
												<div class="tabbable">
													<ul class="nav nav-tabs nav-tabs-highlight">
													<?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li><a href="#highlights-tab<?php echo e($result->id_jenjang); ?>" data-toggle="tab" class="legitRipple"><?php echo e($result->nm_jenjang); ?></a></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</ul>

													<div class="tab-content">
														<?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<div class="tab-pane" id="highlights-tab<?php echo e($result->id_jenjang); ?>">
															<?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultM): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<?php if($result->id_jenjang==$resultM->id_jenjang): ?>
																<a href="<?php echo e(base_url('main/prediksi/'.$resultM->id_mapel)); ?>"><button type="submit" style="margin-top: 15px" class="btn btn-primary legitRipple"><?php echo e($resultM->nm_mapel); ?> <i class="icon-arrow-right14 position-right"></i></button></a>
																<?php endif; ?>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
								<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
							</div>
						</div>
					</div>
				</div>

	<!-- Footer -->
	<!-- <div class="footer text-muted">
		&copy; 2015. <a href="#">Limitless Web App Kit</a> by <a href="http://themeforest.net/user/Kopyov" target="_blank">Eugene Kopyov</a>
	</div> -->
	<!-- /footer -->

</body>
</html>
