<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <link rel="stylesheet" href="<?php echo e(base_url()); ?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/style.css" media="screen">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/icons/icomoon/styles.css" media="screen">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/common.css" media="screen">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/core.css" media="screen">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/components.css" media="screen">
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/colors.css" media="screen">
  <?php echo $__env->yieldContent('style'); ?>
  <link rel="stylesheet" type="text/css" href="<?php echo e(base_url()); ?>assets/css/secondeffect.css" media="screen">
  <style type="text/css">
    .navbar-default {
      background-color: blue;
      border-color: blue;
      font-weight: bold;
      color: white
    }
    
    .navbar-default .navbar-brand {
          color: white;
    }

    
  </style>
</head>
<body>
  <nav class="navbar navbar-default" style="background-color: blue">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(base_url()); ?>home">WebSiteName</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="#" style="color: white;">Home</a></li>
        <li><a href="#" style="color: white;">Page 1</a></li>
        <li><a href="#" style="color: white;">Page 2</a></li>
        <li><a href="#" style="color: white;">Page 3</a></li>
      </ul>
    </div>
  </nav>

<div class="container">
  <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
<script src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery.min.js"></script>
<?php echo $__env->yieldContent('corejs'); ?>
<script src="<?php echo e(base_url()); ?>assets/js/core/libraries/bootstrap.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/js/core/app.js"></script>

</html>