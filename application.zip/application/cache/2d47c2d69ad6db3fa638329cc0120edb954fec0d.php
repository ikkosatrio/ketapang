<?php $__env->startSection('js'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/pages/sidebar_dual.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<div class="page-header-content" style="margin-top: 30px">
			
		</div>
	</div>
	<!-- /page header -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			
			<!-- /secondary sidebar -->
			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Info alert -->
				<div class="alert alert-info alert-styled-left alert-arrow-left alert-component">
					<button type="button" class="close" data-dismiss="alert"><span>&times;</span><span class="sr-only">Close</span></button>
					<h6 class="alert-heading text-semibold">Pembahasan</h6>
						Nilai and adalah = <?php echo e($jawab['nilai']); ?>

			    </div>
			    <!-- /info alert -->


				<!-- Sidebars overview -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h5 class="panel-title">Soal</h5>
						<div class="heading-elements">
							
	                	</div>
					</div>
					
					<form action="<?php echo e(base_url('main')); ?>" method="post" accept-charset="utf-8">
						<?php 
							$no = 1;
						 ?>						
					<?php $__currentLoopData = $no_soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($hasil == $result->id_soal): ?>
					<div class="panel-body">
							<div class="row">
									<label class="control-label col-lg-3">Soal No <?php echo e($no); ?></label>
								<div class="col-lg-12">
									<div class="well">
									    <?php echo $result->isi_soal; ?>

									</div>
								</div>
							</div>
							<br>
							<div class="row">
								<div class="col-lg-12">
									<ul class="list list-unstyled no-margin-bottom">
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="A"><?php echo e($result->pilihA); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="B"><?php echo e($result->pilihB); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="C"><?php echo e($result->pilihC); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="D"><?php echo e($result->pilihD); ?></li>
									</ul>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-2">
									<label class="control-label">Jabawan =  <?php echo e($result->jawaban); ?></label>
								</div>
								<label class="control-label">Pembahasan</label>
								<div class="col-lg-10">
									<div class="well bg-success">
									    <?php echo $result->pembahasan; ?>

									</div>
								</div>
							</div>	
					<div class="divider">
						<hr>
					</div>
					</div>
					<?php 
						$no++;
					 ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="panel-footer">
						
						<button type="submit" class="btn btn-primary pull-right" style="margin-right: 10px">Selesai</button>
					</div>
					</form>
				</div>
			</div>
			
			<!-- /main content -->
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>