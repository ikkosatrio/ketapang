<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php echo e($config->meta_deskripsi); ?>">
    <meta name="keywords" content="<?php echo e($config->meta_keyword); ?>">
    <meta name="author" content="Pemerintah Desa Ketapang Kuning">
    
    <title><?php echo e(ucfirst($menu)); ?> - <?php echo e($config->name); ?></title>
    
    <!--Favicon-->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="manifest" href="<?php echo e(base_url()); ?>assets/main/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>">
    <meta name="theme-color" content="#ffffff">
    
    <!--Favicon-->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>">
    <link rel="manifest" href="<?php echo e(base_url()); ?>assets/main/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>">
    <meta name="theme-color" content="#ffffff">

   <!--    fonts-->
    <link href='https://fonts.googleapis.com/css?family=Raleway:800,700,500,400,600' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,300italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=PT+Serif:400,400italic,700' rel='stylesheet' type='text/css'>
    
    <link href='https://fonts.googleapis.com/css?family=Alegreya:400,700,700italic,400italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
   
    <!-- Bootstrap -->
    <link href="<?php echo e(base_url()); ?>assets/main/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(base_url()); ?>assets/main/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="<?php echo e(base_url()); ?>assets/main/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(base_url()); ?>assets/main/css/strock-icon.css" rel="stylesheet">
    <!--    owl-carousel-->
    <link rel="stylesheet" href="<?php echo e(base_url()); ?>assets/main/vendors/owlcarousel/owl.carousel.css"> 
    <link href="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/css/settings.css" rel="stylesheet">
    <link href="<?php echo e(base_url()); ?>assets/main/vendors/magnific/magnific-popup.css" rel="stylesheet">
    <!--    css-->
    <link rel="stylesheet" href="<?php echo e(base_url()); ?>assets/main/css/style.css">
    <?php echo $__env->yieldContent('css'); ?>
   
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="<?php echo e(base_url()); ?>assets/main/https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="<?php echo e(base_url()); ?>assets/main/https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    
</head>
<body>
<header class="row header navbar-static-top" id="main_navbar">
    <div class="container">
        <div class="row m0 social-info">
            <ul class="social-icon">
                
                <li class="tel"><a href="tel:<?php echo e($config->phone); ?>"><i class="fa fa-phone"></i> <?php echo e($config->phone); ?> </a></li>
                <li class="email"><a href="mailto:<?php echo e($config->email); ?>"><i class="fa fa-envelope-o"></i> <?php echo e($config->email); ?></a></li>
            </ul>
        </div>
    </div>
   <div class="logo_part">
        <div class="logo">
            <a href="<?php echo e(base_url()); ?>assets/main/index.html" class="brand_logo">
                <img src="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>" style="height: 48px" alt="logo image">
            </a>
        </div>
    </div>
    <div class="main-menu">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main_nav" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Collect the nav links, forms, and other content for toggling -->
            
            <div class="menu row m0">                
                <ul class="nav navbar-nav navbar-right visible-sm">
                    
                    <li class="dropdown">
                       
                        
                    </li>
                </ul>
                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="nav navbar-nav">
                        <li class="<?php echo e(match($menu,'home','active')); ?>"><a href="<?php echo e(base_url()); ?>">Home</a></li>
                        <li class="<?php echo e(match($menu,'profil','active')); ?>"><a href="<?php echo e(base_url('main/profil')); ?>">Profil Desa</a></li>
                        <li class="<?php echo e(match($menu,'artikel','active')); ?>"><a href="<?php echo e(base_url('main/artikel')); ?>">Artikel</a></li>
                        <li class="<?php echo e(match($menu,'produk','active')); ?>"><a href="<?php echo e(base_url('main/produk')); ?>">Produk</a></li>
                         <li class="<?php echo e(match($menu,'potensi','active')); ?>"><a href="<?php echo e(base_url('main/potensi')); ?>">Potensi</a></li>
                        <li class="<?php echo e(match($menu,'gallery','active')); ?>"><a href="<?php echo e(base_url('main/gallery')); ?>">Gallery</a></li>
                        
                        <li class="<?php echo e(match($menu,'contact','active')); ?>"><a href="<?php echo e(base_url('main/contact')); ?>">Kontak</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right hidden-xs hidden-sm">
                        
                        
                    </ul>
                </div>
            </div><!-- /.navbar-collapse -->
        </nav>
    </div>
</header>


<!--experiance-area-->
<?php echo $__env->yieldContent('content'); ?>

<!--great-work-->


<!--footer-->
<footer class="row">
    <div class="row m0 footer-top">
        <div class="container">
            <div class="row footer-sidebar">
                <div class="widget about-us-widget col-sm-6 col-lg-3">
                    <a href="<?php echo e(base_url()); ?>" class="brand_logo">
                        <img src="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>" alt="logo image">
                    </a>
                    <p><?php echo $config->description; ?></p>
                    <div class="social-icon row m0">
                        <ul class="nav">
                            <li><a href="<?php echo e(base_url()); ?>assets/main/#"><i class="fa fa-facebook-square"></i></a></li>
                            <li><a href="<?php echo e(base_url()); ?>assets/main/#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="widget widget-links col-sm-6 col-lg-3">
                    <h4 class="widget_title">Menu</h4>
                    <div class="widget-contact-list row m0">
                        <ul>
                            <li><a href="<?php echo e(base_url()); ?>"><i class="fa fa-angle-right"></i>Home</a></li>
                            <li><a href="<?php echo e(base_url('main/profil')); ?>"><i class="fa fa-angle-right"></i>Profil Desa</a></li>
                            <li><a href="<?php echo e(base_url('main/artikel')); ?>"><i class="fa fa-angle-right"></i>Artikel</a></li>
                            <li><a href="<?php echo e(base_url('main/produk')); ?>"><i class="fa fa-angle-right"></i>Produk</a></li>
                            <li><a href="<?php echo e(base_url('main/potensi')); ?>"><i class="fa fa-angle-right"></i>Potensi</a></li>
                            <li><a href="<?php echo e(base_url('main/gallery')); ?>"><i class="fa fa-angle-right"></i>Gallery</a></li>
                            <li><a href="<?php echo e(base_url('main/contact')); ?>"><i class="fa fa-angle-right"></i>Kontak</a></li>
                        </ul>
                    </div>
                </div>
                <div class="widget widget-contact  col-sm-6 col-lg-3">
                    <h4 class="widget_title">Kontak</h4>
                    <div class="widget-contact-list row m0">
                       <ul>
                            <li>
                                <i class="fa fa-map-marker"></i>
                                <div class="fleft location_address">
                                    <?php echo e($config->address); ?>

                                </div>
                                
                            </li>
                            <li>
                                <i class="fa fa-phone"></i>
                                <div class="fleft contact_no">
                                    <a href="tel:<?php echo e($config->phone); ?>"><?php echo e($config->phone); ?></a>
                                </div>
                            </li>
                            <li>
                                <i class="fa fa-envelope-o"></i>
                                <div class="fleft contact_mail">
                                    <a href="mailto:<?php echo e($config->email); ?>"><?php echo e($config->email); ?></a>
                                </div>
                            </li>
                            
                        </ul>
                    </div>
                </div>
                <div class="widget widget4 widget-form col-sm-6 col-lg-3">
                    <h4 class="widget_title">Kirim Saran & Kritik</h4>
                    <div class="widget-contact-list row m0">
                        <form class="submet-form row m0" action="#" method="post">
                            <input type="text" class="form-control" id="name" placeholder="Nama">
                            <input type="email" class="form-control" id="email" placeholder="Email">
                            <textarea class="form-control message" placeholder="Pesan"></textarea>
                            <button class="submit" type="submit">Kirim Sekarang</button>
                        </form>
                       
                    </div>
                </div>
            </div>
        </div>
     </div>
     <div class="row m0 footer-bottom">
         <div class="container">
            <div class="row">
               <div class="col-sm-8">
                   Copyright &copy; <a href="<?php echo e(base_url()); ?>">Ketapang Kuning</a> 2017. <br class="visible-xs"> All rights reserved.
               </div>
               <div class="right col-sm-4">
                   Created by: <a href="http://untag-sby.ac.id/">KKN 10 2017 - Universitas 17 Agustus 1945 Surabaya</a>
               </div>
            </div>
        </div>
     </div>
</footer>
   
<script src="<?php echo e(base_url()); ?>assets/main/js/jquery-2.2.0.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/js/bootstrap.min.js"></script>
<!--RS-->	
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/jquery.themepunch.tools.min.js"></script> <!-- Revolution Slider Tools -->
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/jquery.themepunch.revolution.min.js"></script> <!-- Revolution Slider -->
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/rs-plugin/js/extensions/revolution.extension.video.min.js"></script>

<script src="<?php echo e(base_url()); ?>assets/main/vendors/isotope/isotope.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/owlcarousel/owl.carousel.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/vendors/magnific/jquery.magnific-popup.min.js"></script>
<script src="<?php echo e(base_url()); ?>assets/main/js/theme.js"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>