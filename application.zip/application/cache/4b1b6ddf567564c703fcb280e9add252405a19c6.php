<?php $__env->startSection('title'); ?>
NEXAPP
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-container">
  <div class="page-content">
    <div class="content-wrapper">
      

<div class="row">
  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/TppLrc-0uns" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Mana yang duluan, ayam atau telur ?</h3>
      </div>
    </div>
  </div>

  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/J4KZaTdY7EY" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Dapatkah Anda Memecahkan Teka-Teki Kebohongan Ini ?</h3>
      </div>
    </div>
  </div>

  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/V9XojA8yf7o" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Teka-Teki Menyeberangi Sungai</h3>
      </div>
    </div>
  </div>
</div>  

<div class="row">
  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/Os0bROgQ_ZY" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Kenapa 1 Menit itu 60 detik, Ngga 100 Detik ?</h3>
      </div>
    </div>
  </div>

  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/zDh5r2jbI18" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Siapakah Pribumi Asli Indonesia ?</h3>
      </div>
    </div>
  </div>

  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/4gMaP25y6v8" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Kenapa Perjalanan Pulang Terasa Lebih Cepat Daripada Pergi ?</h3>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/fPqo3YjqH6U" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>Tes Idiot</h3>
      </div>
    </div>
  </div>

  <div class="col-sm-12 col-md-4">
    <div class="thumbnail">
      <iframe width="100%" height="300px" src="https://www.youtube.com/embed/_jbYeyqHZm4" frameborder="0" allowfullscreen></iframe>
      <div class="caption">
        <h3>tes IQ#2 - Seberapa pintarkah anda?</h3>
      </div>
    </div>
  </div>


</div>    



    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>