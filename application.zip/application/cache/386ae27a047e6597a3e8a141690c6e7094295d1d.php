<?php header('Content-type: application/xml; charset="ISO-8859-1"',true);  ?>
 
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
     <loc><?php echo base_url();?></loc>
     <priority>1.0</priority>
  </url>

  <?php $__currentLoopData = $artikelBaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <url>
     <loc><?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?></loc>
     <priority>0.5</priority>
     <image:image>
      <image:loc><?php echo e(img_artikel($result->cover)); ?></image:loc>
      <image:title><?php echo e($result->judul); ?></image:title>
    </image:image>
     <lastmod><?php echo e($result->created_at); ?></lastmod>
  </url>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $potensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <url>
     <loc><?php echo e(base_url('main/potensi/'.$result->id_potensi.'/'.seo($result->judul))); ?></loc>
     <priority>0.5</priority>
     <image:image>
      <image:loc><?php echo e(img_potensi($result->cover)); ?></image:loc>
      <image:title><?php echo e($result->judul); ?></image:title>
    </image:image>
     <lastmod><?php echo e($result->created_at); ?></lastmod>
  </url>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <url>
     <loc><?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?></loc>
     <priority>0.5</priority>
     <image:image>
      <image:loc><?php echo e(img_produk($result->cover)); ?></image:loc>
      <image:title><?php echo e($result->judul); ?></image:title>
    </image:image>
     <lastmod><?php echo e($result->created_at); ?></lastmod>
  </url>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</urlset>