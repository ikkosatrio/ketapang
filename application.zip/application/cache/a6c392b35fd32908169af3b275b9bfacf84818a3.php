<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/datatables_basic.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="datatable_basic.html">Jenjang</a></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">

					<!-- Basic datatable -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Data Member</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<table class="table datatable-basic">
							<thead>
								<tr>
									<th>No</th>
									<th>ID Member </th>
									<th>Nama </th>
									<th>Email </th>
									<th>Phone </th>
									<th>Status Member </th>
									<th class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e(($key+1)); ?></td>
									<td><?php echo e($result->id_member); ?></td>
									<td><a href="#"><?php echo e($result->name); ?></a></td>
									<td><?php echo e($result->email); ?></td>
									<td><?php echo e($result->phone); ?></td>
									<td><span class="label <?php echo e(($result->status_member=="basic") ? 'label-primary' : 'label-danger'); ?>"><?php echo e($result->status_member); ?></span></td>
									<td class="text-center">
										<ul class="icons-list">
											<li class="dropdown">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown">
													<i class="icon-menu9"></i>
												</a>

												<ul class="dropdown-menu dropdown-menu-right">
													<?php if($result->status_member=="basic"): ?>
													<li><a href="<?php echo e(base_url('superuser/member/premium/'.$result->id_member)); ?>"><i class="icon-share4"></i> Ganti Premium</a></li>
													<?php else: ?>
													<li><a href="<?php echo e(base_url('superuser/member/basic/'.$result->id_member)); ?>"><i class="icon-move-down"></i> Ganti Basic</a></li>
													<?php endif; ?>

													<li><a href="javascript:void(0)" onclick="deleteIt(this)" data-url="<?php echo e(base_url('superuser/member/deleted/'.$result->id_member)); ?>"><i class="icon-trash"></i> Hapus</a></li>
												</ul>
											</li>
										</ul>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<!-- /basic datatable -->					

				</div>
				<!-- /content area -->

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>