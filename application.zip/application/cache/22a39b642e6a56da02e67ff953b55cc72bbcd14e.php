<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_inputs.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_select2.js"></script>

	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/wysihtml5.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/toolbar.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/parsers.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/locales/bootstrap-wysihtml5.ua-UA.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/editor_wysihtml5.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li><a href="<?php echo e(base_url('superuser/bab')); ?>">Bab</a></li>
							<li class="active"><?php echo e(($type=="create") ? 'Tambah Data Bab' : 'Perbarui Data Bab'); ?></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->
				<!-- Content area -->
				<div class="content">

					<!-- Form horizontal -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Tambah data Bab</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal" id="form_bab" action="<?php echo e(($type=='create') ? base_url('superuser/bab/created') : base_url('superuser/bab/updated/'.$bab->id_bab)); ?>" method="post">
								<fieldset class="content-group">
									

									<div class="form-group">
										<label class="control-label col-lg-2">Nama Bab</label>
										<div class="col-lg-10">
											<input type="text" class="form-control" name="nm_bab" value="<?php echo e(($type=='create') ? '' : $bab->nm_bab); ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Mata Pelajaran/Jenjang</label>
										<div class="col-lg-10">
										<select required class="select-search" name="mapel">
											<optgroup label="Pilih Jenjang">
												<option value="">Pilih</option>
												<?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option 
														<?php if($type=='update'): ?>
														<?php echo e(($bab->id_mapel==$result->id_mapel) ? "selected" : ""); ?> 
														<?php endif; ?>
														value="<?php echo e($result->id_mapel); ?>"><?php echo e($result->nm_mapel); ?> - <?php echo e($result->nm_jenjang); ?>

													</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</optgroup>
										</select>
										</div>
									</div>
									
									<div class="form-group">
										<label class="control-label col-lg-2">Materi</label>
										<div class="col-lg-10">
											<input type="text" class="form-control" placeholder="Judul Materi" name="materi[]" value="" required>
											<textarea rows="5" cols="5" name="isiMateri[]" class=" wysihtml5 wysihtml5-default form-control" placeholder="Isi Materi"></textarea>
										</div>
										<div class="text-right">
							                <button style="margin-top: 10px" type="button" class="btn btn-danger" onclick="removeMateri(this)">Hapus Materi</button>
										</div>
									</div>
									<div id="box-materi">
									</div>
								</fieldset>
								<div class="text-right">
									<button type="submit" class="btn btn-primary"><?php echo e(($type=='create') ? 'Simpan' : 'Edit'); ?> <i class="icon-arrow-right14 position-right"></i></button>
								</div>
							</form>
						</div>
					</div>
					<!-- /form horizontal -->

					
					<!-- Footer -->
					
					<!-- /footer -->

				</div>
			</div>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
	function NewMateri(){
		
		var html         = 		'<div class="form-group">'+
										'<label class="control-label col-lg-2">Materi</label>'+
										'<div class="col-lg-10">'+
											'<input type="text" class="form-control" placeholder="Judul Materi" name="materi[]" value="" required>'+
											'<textarea rows="5" cols="5" name="description" class=" wysihtml5 wysihtml5-default form-control" placeholder="Isi Materi"></textarea>'+
										'</div>'+
										'<div class="text-right">'+
							                '<button style="margin-top: 10px;margin-bottom: 10px;" type="button" class="btn btn-danger" onclick="removeMateri(this)">Hapus Materi</button>'+
										'</div>'+
								'</div>';
		$("#box-materi").append(html);
	}

	function removeMateri(that){
		$(that).parents('.form-group').remove();
	}

	$("#form_bab").submit(function(e){
			e.preventDefault();
			var formData = new FormData( $("#form_bab")[0] );

			$.ajax({
				url: 		$("#form_bab").attr('action'),
				type: 	"POST",
				data:  		new FormData(this),
          		processData: false,
          		contentType: false,
				beforeSend: function(){
					blockMessage($('#form_bab'),'Please Wait , <?php echo e(($type =="create") ? "Menambahkan Bab" : "Memperbarui Bab"); ?>','#fff');		
				}
			})
			.done(function(data){
				$('#form_bab').unblock();
				sweetAlert({
					title: 	((data.auth==false) ? "Opps!" : '<?php echo e(($type =="create") ? "Bab Di Buatkan" : "Bab Di Perbarui"); ?>'),
					text: 	data.msg,
					type: 	((data.auth==false) ? "error" : "success"),
				},
				function(){
					if(data.auth!=false){
						redirect("<?php echo e(base_url('superuser/bab')); ?>");		
						return;
					}
				});
			})
			.fail(function() {
			    $('#form_bab').unblock();
				sweetAlert({
					title: 	"Opss!",
					text: 	"Ada Yang Salah! , Silahkan Coba Lagi Nanti",
					type: 	"error",
				},
				function(){
					
				});
			 })
			
		})
	</script>
	
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>