<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.countdown.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/main/js/pages/sidebar_dual.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.plugin.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.countdown.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.countdown-id.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<div class="page-header-content" style="margin-top: 30px">
			
		</div>
	</div>
	<!-- /page header -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="sidebar sidebar-main sidebar-default sidebar-separate">
				<div class="sidebar-content">

					<!-- Action buttons -->
					<div class="sidebar-category">
						<div class="category-title">
							<span>Navigasi Soal</span>
							<ul class="icons-list">
								<li><a href="#" data-action="collapse"></a></li>
							</ul>
						</div>

						<div class="category-content">
							<div class="row">
								<div class="col-xs-12">
									<div id="waktu" style="height: 50px">
										
									</div>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
			<!-- /secondary sidebar -->
			<!-- Main content -->
			<div class="content-wrapper">

				<!-- Info alert -->
				<div class="alert alert-info alert-styled-left alert-arrow-left alert-component">
					<button type="button" class="close" data-dismiss="alert"><span>&times;</span><span class="sr-only">Close</span></button>
					<h6 class="alert-heading text-semibold">Pemberiatahuan</h6>
					You can use sidebar categories as separate widgets. To use, add <code>.sidebar-separate</code> class to the sidebar container.
			    </div>
			    <!-- /info alert -->


				<!-- Sidebars overview -->
				<div class="panel panel-flat">
					<div class="panel-heading">
						<h5 class="panel-title">Soal</h5>
						<div class="heading-elements">
							
	                	</div>
					</div>
					
					<form action="<?php echo e(base_url('main/prediksi/jawab')); ?>" id="#formSoal" method="post" accept-charset="utf-8">
					<?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
					<div class="panel-body">
							<div class="row">
									<label class="control-label col-lg-3">Soal No <?php echo e($key+1); ?></label>
								<div class="col-lg-12">
								<input type="text" name="no_soal[]" style="display: none" value="<?php echo e($result->id_soal); ?>">
									<div class="well">
					                    <?php echo $result->isi_soal; ?>

									</div>
								</div>
							</div>
							<br>
							<div class="row">
								<div class="col-lg-12">
									<ul class="list list-unstyled no-margin-bottom">
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="A"><?php echo e($result->pilihA); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="B"><?php echo e($result->pilihB); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="C"><?php echo e($result->pilihC); ?></li>
										<li><input type="radio" name="pilih<?php echo e($result->id_soal); ?>[]" value="D"><?php echo e($result->pilihD); ?></li>
									</ul>
								</div>
							</div>	
					<div class="divider">
						<hr>
					</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="panel-footer">
						
						<button type="submit" onclick="hapusCookies()" class="btn btn-primary pull-right" style="margin-right: 10px">Selesai</button>
					</div>
					</form>
				</div>
			</div>
			<script type="text/javascript">
				var waktu = 0
				if (localStorage.getItem("detik2")!=null) {
					var waktu = localStorage.getItem("detik2");
				}else{
					var waktu = <?php echo e($mapel->waktu*60); ?>;
				}
				$('#waktu').countdown({
					 until: waktu ,
					 onExpiry: function(){
					 	localStorage.clear();
					    alert("Waktu Selesai");
					 	$('#formSoal').submit();
					 },
					 onTick: simpanCookies

				});
				function hapusCookies() { 
				   localStorage.clear();
				};
				function simpanCookies() { 
				    var periods = $('#waktu').countdown('getTimes');
				    localStorage.setItem('detik2', $.countdown.periodsToSeconds(periods));
				    // alert($.countdown.periodsToSeconds(periods)); 
				};
				$(document).ready(function(){
    				localStorage.clear();
				});
			</script>
			<!-- /main content -->
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>