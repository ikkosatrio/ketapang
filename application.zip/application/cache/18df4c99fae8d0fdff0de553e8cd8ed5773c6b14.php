<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_inputs.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_select2.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li><a href="<?php echo e(base_url('superuser/mapel')); ?>">Mapel</a></li>
							<li class="active"><?php echo e(($type=="create") ? 'Tambah Data Mapel' : 'Perbarui Data Mapel'); ?></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->
				<!-- Content area -->
				<div class="content">

					<!-- Form horizontal -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Tambah data Mapel</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal" id="form_mapel" action="<?php echo e(($type=='create') ? base_url('superuser/mapel/created') : base_url('superuser/mapel/updated/'.$mapel->id_mapel)); ?>" method="post">
								<fieldset class="content-group">
									

									<div class="form-group">
										<label class="control-label col-lg-2">Nama Mata Pelajaran</label>
										<div class="col-lg-10">
											<input type="text" class="form-control" name="nm_mapel" value="<?php echo e(($type=='create') ? '' : $mapel->nm_mapel); ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Jenjang</label>
										<div class="col-lg-10">
										<select required class="select-search" name="jenjang">
											<optgroup label="Pilih Jenjang">
												<option value="">Pilih</option>
												<?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option 
														<?php if($type=='update'): ?>
														<?php echo e(($mapel->id_jenjang==$result->id_jenjang) ? "selected" : ""); ?> 
														<?php endif; ?>
														value="<?php echo e($result->id_jenjang); ?>"><?php echo e($result->nm_jenjang); ?>

													</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</optgroup>
										</select>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Jumlah Soal</label>
										<div class="col-lg-10">
											<input type="number" class="form-control" name="jumlah_soal" value="<?php echo e(($type=='create') ? '' : $mapel->jumlah_soal); ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Waktu Pengerjaan</label>
										<div class="col-lg-10">
											<input type="number" class="form-control" placeholder="satuan menit" name="waktu" value="<?php echo e(($type=='create') ? '' : $mapel->waktu); ?>" required>
										</div>
									</div>
								</fieldset>
								<div class="text-right">
									<button type="submit" class="btn btn-primary"><?php echo e(($type=='create') ? 'Simpan' : 'Edit'); ?> <i class="icon-arrow-right14 position-right"></i></button>
								</div>
							</form>
						</div>
					</div>
					<!-- /form horizontal -->

					
					<!-- Footer -->
					
					<!-- /footer -->

				</div>
			</div>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
	$("#form_mapel").submit(function(e){
			e.preventDefault();
			var formData = new FormData( $("#form_mapel")[0] );

			$.ajax({
				url: 		$("#form_mapel").attr('action'),
				type: 	"POST",
				data:  		new FormData(this),
          		processData: false,
          		contentType: false,
				beforeSend: function(){
					blockMessage($('#form_mapel'),'Please Wait , <?php echo e(($type =="create") ? "Menambahkan Mapel" : "Memperbarui Mapel"); ?>','#fff');		
				}
			})
			.done(function(data){
				$('#form_mapel').unblock();
				sweetAlert({
					title: 	((data.auth==false) ? "Opps!" : '<?php echo e(($type =="create") ? "Mapel Di Buatkan" : "Mapel Di Perbarui"); ?>'),
					text: 	data.msg,
					type: 	((data.auth==false) ? "error" : "success"),
				},
				function(){
					if(data.auth!=false){
						redirect("<?php echo e(base_url('superuser/mapel')); ?>");		
						return;
					}
				});
			})
			.fail(function() {
			    $('#form_mapel').unblock();
				sweetAlert({
					title: 	"Opss!",
					text: 	"Ada Yang Salah! , Silahkan Coba Lagi Nanti",
					type: 	"error",
				},
				function(){
					
				});
			 })
			
		})
	</script>
	
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>