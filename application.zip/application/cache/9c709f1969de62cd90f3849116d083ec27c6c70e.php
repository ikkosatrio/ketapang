<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/datatables_basic.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="<?php echo e(base_url('superuser/bab')); ?>">Bab</a></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">

					<!-- Basic datatable -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Data Soal</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<table class="table datatable-basic">
							<thead>
								<tr>
									<th style="width: 10%">No</th>
									<th style="width: 20%">Soal</th>
									<th>Bab</th>
									<th>Mapel / Jenjang</th>
									<th style="width: 10%" class="text-center">Actions</th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e(($key+1)); ?></td>
									<td><a href="<?php echo e(base_url('superuser/soal/update/'.$result->id_bab.'/'.$result->id_soal)); ?>"><?php echo e(ucwords(read_more($result->isi_soal,100))); ?>...</a></td>
									<td><?php echo e($result->nm_bab); ?></td>
									<td><?php echo e($result->nm_mapel); ?> - <?php echo e($result->nm_jenjang); ?></td>
									<td class="text-center">
										<ul class="icons-list">
											<li class="dropdown">
												<a href="#" class="dropdown-toggle" data-toggle="dropdown">
													<i class="icon-menu9"></i>
												</a>
												
												<ul class="dropdown-menu dropdown-menu-right">
													<li><a href="<?php echo e(base_url('superuser/soal/update/'.$result->id_bab.'/'.$result->id_soal)); ?>"><i class="icon-pencil7"></i> Edit</a></li>
													<li><a href="javascript:void(0)" onclick="deleteIt(this)" data-url="<?php echo e(base_url('superuser/soal/deleted/'.$result->id_bab.'/'.$result->id_soal)); ?>"><i class="icon-trash"></i> Hapus</a></li>
												</ul>
											</li>
										</ul>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<!-- /basic datatable -->					

				</div>
				<!-- /content area -->

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>