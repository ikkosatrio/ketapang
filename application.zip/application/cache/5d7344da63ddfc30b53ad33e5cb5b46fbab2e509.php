<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery_ui/interactions.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_inputs.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/form_select2.js"></script>

	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/wysihtml5.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/toolbar.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/parsers.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/editors/wysihtml5/locales/bootstrap-wysihtml5.ua-UA.js"></script>
	
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/uploaders/fileinput.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/uploader_bootstrap.js"></script>
	
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/editor_wysihtml5.js"></script>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li><a href="<?php echo e(base_url('superuser/bab')); ?>">Bab</a></li>
							<li class="active"><?php echo e(($type=="create") ? 'Tambah Data Bab' : 'Perbarui Data Bab'); ?></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->
				<!-- Content area -->
				<div class="content">

					<!-- Form horizontal -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Tambah Soal Bab</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal" id="form_soal" action="<?php echo e(($type=='create') ? base_url('superuser/soal/created/'.$bab->id_bab) : base_url('superuser/soal/updated/'.$soal->id_soal)); ?>" method="post">
								<fieldset class="content-group">
									

									<div class="form-group">
										<label class="control-label col-lg-2">Nama Bab</label>
										<div class="col-lg-10">
											<input type="text" class="form-control" readonly name="nm_bab" value="<?php echo e(($type=='create') ? $bab->nm_bab : $bab->nm_bab); ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Mata Pelajaran/Jenjang</label>
										<div class="col-lg-10">
										<select required class="select-search" disabled name="mapel">
											<optgroup label="Pilih Jenjang">
												<option value="">Pilih</option>
												<?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option 
														<?php if($type=='update' or $type=='create'): ?>
														<?php echo e(($bab->id_mapel==$result->id_mapel) ? "selected" : ""); ?> 
														<?php endif; ?>
														value="<?php echo e($result->id_mapel); ?>"><?php echo e($result->nm_mapel); ?> - <?php echo e($result->nm_jenjang); ?>

													</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</optgroup>
										</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-lg-2 control-label text-semibold">File Audio:</label>
										<div class="col-lg-10">
											<?php if($soal->audio!=null): ?>
											<?php 
												$soal->audio = str_replace(' ', '_', $soal->audio);
											 ?>
												<audio src="<?php echo e(base_url()); ?>assets/audio/<?php echo e($soal->audio); ?>" autobuffer autoloop loop controls></audio>
											<?php endif; ?>
											<input type="file" name="audio" class="file-input" data-show-upload="false">
											<span class="help-block">Inputan ini dikhususkan untuk soal listening atau memiliki audio jika tidak ada audio silahkan hiraukan inputan ini.<code>pastikan format file .mp3</code></span>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Soal</label>
										<div class="col-lg-10">
											<textarea rows="10" cols="100" name="isiSoal" class="wysihtml5 wysihtml5-default2 form-control" placeholder="Isi Soal"><?php echo e(($type=='create') ? '' : $soal->isi_soal); ?></textarea>
										<div class="form-group">
											<label class="text-semibold">Jawaban</label>
											<div class="radio">
												<label>
													<input type="radio" name="jawaban" <?php if($type=='update'): ?><?php echo e(($soal->jawaban=='A') ? 'checked' : ''); ?><?php endif; ?> value="A">
													

													A<textarea class=" wysihtml5 wysihtml5-default2 form-control form-control" placeholder="A" required="" name="pilihA"><?php echo e(($type=='create') ? '' : $soal->pilihA); ?></textarea>
												</label>
											</div>

											<div class="radio">
												<label>
													<input type="radio" name="jawaban" <?php if($type=='update'): ?><?php echo e(($soal->jawaban=='B') ? 'checked' : ''); ?><?php endif; ?> value="B">
													

													B<textarea class=" wysihtml5 wysihtml5-default2 form-control form-control" placeholder="B" required="" name="pilihB"><?php echo e(($type=='create') ? '' : $soal->pilihB); ?></textarea>
												</label>
											</div>

											<div class="radio">
												<label>
													<input type="radio" name="jawaban" <?php if($type=='update'): ?><?php echo e(($soal->jawaban=='C') ? 'checked' : ''); ?><?php endif; ?> value="C">
													
													C<textarea class=" wysihtml5 wysihtml5-default2 form-control form-control" placeholder="C" required="" name="pilihC"><?php echo e(($type=='create') ? '' : $soal->pilihC); ?></textarea>
												</label>
											</div>

											<div class="radio">
												<label>
													<input type="radio" name="jawaban" <?php if($type=='update'): ?><?php echo e(($soal->jawaban=='D') ? 'checked' : ''); ?><?php endif; ?> value="D">
													
													D<textarea class=" wysihtml5 wysihtml5-default2 form-control form-control" placeholder="D" required="" name="pilihD"><?php echo e(($type=='create') ? '' : $soal->pilihD); ?></textarea>
												</label>
											</div>

											<div class="radio">
												<label>
													<input type="radio" name="jawaban" <?php if($type=='update'): ?><?php echo e(($soal->jawaban=='E') ? 'checked' : ''); ?><?php endif; ?> value="E">
													
													E<textarea class=" wysihtml5 wysihtml5-default2 form-control form-control" placeholder="E" required="" name="pilihE"><?php echo e(($type=='create') ? '' : $soal->pilihE); ?></textarea>
												</label>
											</div>
										</div>
										</div>
										
										
									</div>
									<div class="form-group">
										<label class="control-label col-lg-2">Pembahasan</label>
										<div class="col-lg-10">
											<textarea rows="5" cols="5" name="pembahasan" class=" wysihtml5 wysihtml5-default2 form-control" placeholder="Isi PEmbahsana"><?php echo e(($type=='create') ? '' : $soal->pembahasan); ?></textarea>
								</fieldset>
								<div class="text-right">
									<button type="submit" class="btn btn-primary"><?php echo e(($type=='create') ? 'Simpan' : 'Edit'); ?> <i class="icon-arrow-right14 position-right"></i></button>
								</div>
							</form>
						</div>
					</div>
					<!-- /form horizontal -->

					
					<!-- Footer -->
					
					<!-- /footer -->

				</div>
			</div>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/editor_ckeditor.js"></script>
	<script type="text/javascript">
	// function NewMateri(){
		
	// 	var html         = 			'<div class="form-group">'+
	// 								'<label class="control-label col-lg-2">Soal</label>'+
	// 									'<div class="col-lg-10">'+
	// 										'<textarea rows="5" cols="5" name="isiMateri[]" class=" wysihtml5 wysihtml5-default form-control" placeholder="Isi Soal"></textarea>'+
	// 									'<div class="form-group">'+
	// 										'<label class="text-semibold">Jawaban</label>'+
	// 										'<div class="radio">'+
	// 											'<label>'+
	// 												'<input type="radio" name="jawaban">'+
	// 												'<input type="text" class="form-control" name="pilihA" value="" placeholder="A" required="">'+
	// 											'</label>'+
	// 										'</div>'+

	// 										'<div class="radio">'+
	// 											'<label>'+
	// 												'<input type="radio" name="jawaban">'+
	// 												'<input type="text" class="form-control" name="pilihB" value="" placeholder="B" required="">'+
	// 											'</label>'+
	// 										'</div>'+

	// 										'<div class="radio">'+
	// 											'<label>'+
	// 												'<input type="radio" name="jawaban">'+
	// 												'<input type="text" class="form-control" name="pilihC" value="" placeholder="C" required="">'+
	// 											'</label>'+
	// 										'</div>'+

	// 										'<div class="radio">'+
	// 											'<label>'+
	// 												'<input type="radio" name="jawaban">'+
	// 												'<input type="text" class="form-control" name="pilihD" value="" placeholder="D" required="">'+
	// 											'</label>'+
	// 										'</div>'+
	// 									'</div>'+
	// 									'</div>'+
										
	// 									'<div class="text-right">'+
	// 						               ' <button style="margin-top: 10px" type="button" class="btn btn-danger" onclick="removeMateri(this)">Hapus Materi</button>'+
	// 									'</div>'+
	// 									'</div>';
	// 	$("#box-materi").append(html);
	// }

	// function removeMateri(that){
	// 	$(that).parents('.form-group').remove();
	// }

	$("#form_soal").submit(function(e){
			e.preventDefault();
			var formData = new FormData( $("#form_soal")[0] );

			$.ajax({
				url: 		$("#form_soal").attr('action'),
				type: 	"POST",
				data:  		new FormData(this),
          		processData: false,
          		contentType: false,
				beforeSend: function(){
					blockMessage($('#form_soal'),'Please Wait , <?php echo e(($type =="create") ? "Menambahkan Bab" : "Memperbarui Bab"); ?>','#fff');		
				}
			})
			.done(function(data){
				$('#form_soal').unblock();
				sweetAlert({
					title: 	((data.auth==false) ? "Opps!" : '<?php echo e(($type =="create") ? "Bab Di Buatkan" : "Bab Di Perbarui"); ?>'),
					text: 	data.msg,
					type: 	((data.auth==false) ? "error" : "success"),
				},
				function(){
					if(data.auth!=false){
						redirect("<?php echo e(base_url('superuser/soal/list/'.$bab->id_bab)); ?>");		
						return;
					}
				});
			})
			.fail(function() {
			    $('#form_soal').unblock();
				sweetAlert({
					title: 	"Opss!",
					text: 	"Ada Yang Salah! , Silahkan Coba Lagi Nanti",
					type: 	"error",
				},
				function(){
					
				});
			 })
			
		})
	</script>
	
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>