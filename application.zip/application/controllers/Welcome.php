<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->blade->sebarno('ctrl', $this);
	}

	public function index()
	{
		echo $this->blade->nggambar('welcome_message');
	}
}
